import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

const plans = [
  {
    name: 'Starter',
    subtitle: 'For individuals and freelancers',
    price: '$29',
    period: '/month',
    features: [
      '10 documents per month',
      'Secure cloud storage',
      'Email support',
      'Basic document analysis',
      'Export to PDF',
    ],
    cta: 'Get Started',
    popular: false,
  },
  {
    name: 'Team',
    subtitle: 'For small firms and teams',
    price: '$99',
    period: '/month',
    features: [
      'Unlimited documents',
      'Team collaboration tools',
      'Priority support',
      'Advanced AI analysis',
      'Custom integrations',
      'Shared knowledge base',
    ],
    cta: 'Get Started',
    popular: true,
  },
  {
    name: 'Enterprise',
    subtitle: 'Custom compliance & integrations',
    price: 'Custom',
    period: '',
    features: [
      'Everything in Team',
      'Dedicated account manager',
      'Custom security controls',
      'SSO & advanced permissions',
      'API access',
      'SLA guarantees',
    ],
    cta: 'Contact Sales',
    popular: false,
  },
];

export default function Pricing() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1F2933] mb-4">
            Simple pricing for every stage
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 lg:gap-10">
          {plans.map((plan, idx) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`relative bg-white rounded-2xl p-8 border-2 transition-all duration-300 ${
                plan.popular
                  ? 'border-[#FF8A3D] shadow-xl shadow-orange-100 scale-105'
                  : 'border-gray-200 hover:border-gray-300 hover:shadow-lg'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-[#FF8A3D] to-[#F45B5B] text-white border-0 px-4 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-[#1F2933] mb-2">
                  {plan.name}
                </h3>
                <p className="text-sm text-gray-600 mb-6">{plan.subtitle}</p>

                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-5xl font-bold text-[#1F2933]">
                    {plan.price}
                  </span>
                  {plan.period && <span className="text-gray-500">{plan.period}</span>}
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <Check className="w-3 h-3 text-green-600" />
                    </div>
                    <span className="text-gray-700 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full py-6 text-base font-semibold ${
                  plan.popular
                    ? 'bg-[#FF8A3D] hover:bg-[#FF8A3D]/90 text-white shadow-lg shadow-orange-200'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                }`}
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

