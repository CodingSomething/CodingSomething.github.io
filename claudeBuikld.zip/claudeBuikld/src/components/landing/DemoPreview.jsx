import React from 'react';
import { Button } from '@/components/ui/button';
import { Play, FileText, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DemoPreview() {
  return (
    <section className="py-20 lg:py-28 bg-gradient-to-br from-orange-50/50 via-[#F9F9FB] to-red-50/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1F2933] mb-4">
            See your AI legal assistant in action
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative max-w-5xl mx-auto"
        >
          <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
            <div className="grid md:grid-cols-2">
              <div className="bg-gray-50 p-8 border-r border-gray-200">
                <div className="flex items-center gap-2 mb-6 pb-4 border-b border-gray-200">
                  <FileText className="w-5 h-5 text-gray-400" />
                  <span className="text-sm font-semibold text-gray-700">
                    Sample_Contract.pdf
                  </span>
                </div>
                <div className="space-y-4 text-sm text-gray-600">
                  <p className="leading-relaxed">
                    This Employment Agreement is entered into between [Company Name]
                    and [Employee Name]...
                  </p>

                  <div className="bg-orange-100 border-l-4 border-[#FF8A3D] p-4 rounded-r">
                    <p className="font-semibold text-gray-800 mb-2">
                      7.2 Termination Clause
                    </p>
                    <p className="leading-relaxed">
                      Either party may terminate this agreement with thirty (30) days
                      written notice. In case of termination for cause, the notice
                      period may be waived. Severance is calculated at two (2) weeks
                      base salary per year of service.
                    </p>
                  </div>
                  <p className="leading-relaxed">
                    All proprietary information and materials shall be returned upon
                    termination...
                  </p>
                </div>
              </div>

              <div className="bg-white p-8">
                <div className="flex items-center gap-2 mb-6 pb-4 border-b border-gray-100">
                  <MessageSquare className="w-5 h-5 text-[#FF8A3D]" />
                  <span className="text-sm font-semibold text-gray-700">
                    AI Legal Assistant
                  </span>
                </div>
                <div className="space-y-4">
                  <div className="bg-gray-100 rounded-xl px-4 py-3 text-sm inline-block">
                    Can you explain the termination clause in simple terms?
                  </div>
                  <div className="bg-gradient-to-br from-[#FF8A3D]/10 to-[#F45B5B]/5 border border-[#FF8A3D]/20 rounded-xl p-5">
                    <p className="font-semibold text-[#1F2933] mb-3">
                      Here&apos;s a simplified explanation of Clause 7.2:
                    </p>

                    <ul className="space-y-2 text-sm text-gray-700">
                      <li className="flex gap-2">
                        <span className="text-[#FF8A3D] font-bold">•</span>
                        <span>
                          <strong>Notice period:</strong> Either you or the company
                          can end the contract with 30 days notice
                        </span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-[#FF8A3D] font-bold">•</span>
                        <span>
                          <strong>For cause:</strong> If there&apos;s a serious
                          violation, termination can be immediate
                        </span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-[#FF8A3D] font-bold">•</span>
                        <span>
                          <strong>Severance:</strong> You&apos;ll get 2 weeks of pay
                          for every year you worked
                        </span>
                      </li>
                    </ul>
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <p className="text-xs text-gray-500">📍 Referenced from: Section 7.2, page 5</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center mt-10"
          >
            <p className="text-gray-600 mb-4">
              Try it with a sample contract in under 60 seconds
            </p>
            <Button
              size="lg"
              className="bg-[#FF8A3D] hover:bg-[#FF8A3D]/90 text-white px-8 py-6 text-base font-semibold shadow-lg shadow-orange-200"
            >
              <Play className="w-5 h-5 mr-2" />
              Launch Interactive Demo
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

