import React from 'react';
import { Button } from '@/components/ui/button';
import {
  FileText,
  MessageSquare,
  CheckCircle,
  Upload,
  Sparkles,
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-orange-50/30 via-white to-red-50/20 pt-20 pb-24 lg:pt-32 lg:pb-32">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,138,61,0.08),transparent_50%)]" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-50 border border-red-100 mb-6">
              <Sparkles className="w-3.5 h-3.5 text-red-500" />
              <span className="text-sm font-medium text-red-600">
                AI-powered legal guidance, built for professionals
              </span>
            </div>

            <h1 className="text-5xl lg:text-6xl xl:text-7xl font-bold text-[#1F2933] leading-[1.1] mb-6">
              Instant legal clarity.{' '}
              <span className="text-[#FF8A3D]">From your documents</span>{' '}
              to clear answers in minutes.
            </h1>

            <p className="text-lg lg:text-xl text-gray-600 leading-relaxed mb-8 max-w-xl">
              Upload your contracts, policies, or dispute documents and talk to
              your personal AI legal assistant—backed by expert-reviewed guidance
              and airtight security.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <Button
                size="lg"
                className="bg-[#FF8A3D] hover:bg-[#FF8A3D]/90 text-white px-8 py-6 text-base font-semibold shadow-lg shadow-orange-200 transition-all hover:shadow-xl hover:shadow-orange-300"
              >
                Get Started – It&apos;s Free to Try
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-[#FF8A3D] text-[#FF8A3D] hover:bg-orange-50 px-8 py-6 text-base font-semibold"
              >
                Book a Demo
              </Button>
            </div>

            <p className="text-sm text-gray-500 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              No credit card required. End-to-end encrypted document handling.
            </p>
          </motion.div>

          {/* Right: Visual Mockup */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
              {/* Browser chrome */}
              <div className="bg-gray-100 px-4 py-3 flex items-center gap-2 border-b border-gray-200">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-yellow-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                </div>
                <div className="flex-1 bg-white rounded px-3 py-1 text-xs text-gray-400 ml-2">
                  app.legalassistant.ai
                </div>
              </div>

              <div className="grid grid-cols-2 h-[400px]">
                {/* Left pane: Document */}
                <div className="bg-gray-50 p-6 overflow-hidden border-r border-gray-200">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 mb-4">
                      <FileText className="w-4 h-4 text-gray-400" />
                      <span className="text-xs font-medium text-gray-500">
                        Employment_Agreement.pdf
                      </span>
                    </div>
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div
                        key={i}
                        className={
                          i === 3
                            ? 'bg-orange-100 border border-orange-200 rounded px-2 py-1.5'
                            : ''
                        }
                      >
                        <div className="h-2 bg-gray-300 rounded w-full mb-1" />
                        <div className="h-2 bg-gray-300 rounded w-4/5" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right pane: Chat */}
                <div className="bg-white p-6 flex flex-col">
                  <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100">
                    <MessageSquare className="w-4 h-4 text-[#FF8A3D]" />
                    <span className="text-xs font-medium text-gray-700">
                      AI Legal Assistant
                    </span>
                  </div>

                  <div className="space-y-3 flex-1 overflow-hidden">
                    <div className="bg-gray-100 rounded-lg p-3 text-xs">
                      What&apos;s the termination clause?
                    </div>
                    <div className="bg-[#FF8A3D]/10 border border-[#FF8A3D]/20 rounded-lg p-3 text-xs text-gray-700">
                      <p className="font-medium mb-1">Termination Clause Summary:</p>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Either party: 30 days notice</li>
                        <li>• Cause: Immediate termination</li>
                        <li>• Severance: 2 weeks per year</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating badges */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="absolute -top-4 -right-4 bg-white px-4 py-2 rounded-xl shadow-lg border border-gray-200 flex items-center gap-2"
            >
              <Upload className="w-4 h-4 text-[#FF8A3D]" />
              <span className="text-xs font-medium text-gray-700">
                Upload PDF, Word, or Images
              </span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="absolute top-1/3 -left-4 bg-white px-4 py-2 rounded-xl shadow-lg border border-gray-200 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#F45B5B]" />
              <span className="text-xs font-medium text-gray-700">
                Smart clause summaries
              </span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="absolute -bottom-4 left-1/4 bg-white px-4 py-2 rounded-xl shadow-lg border border-gray-200 flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-[#FF8A3D]" />
              <span className="text-xs font-medium text-gray-700">
                Ask follow-up questions
              </span>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

