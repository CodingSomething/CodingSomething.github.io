import React from 'react';
import { Rocket, Briefcase, User } from 'lucide-react';
import { motion } from 'framer-motion';

const useCases = [
  {
    icon: Rocket,
    title: 'For Founders & Startups',
    description:
      'Review fundraising term sheets, vendor agreements, and employment contracts before you sign.',
    gradient: 'from-orange-500 to-red-500',
  },
  {
    icon: Briefcase,
    title: 'For In-House Counsel & Ops Teams',
    description:
      'Standardize contract reviews, quickly surface unusual clauses, and maintain clear internal summaries.',
    gradient: 'from-red-500 to-pink-500',
  },
  {
    icon: User,
    title: 'For Freelancers & Individuals',
    description:
      'Understand client contracts, tenancy agreements, employment offers, or dispute letters without the jargon.',
    gradient: 'from-orange-600 to-orange-400',
  },
];

export default function UseCases() {
  return (
    <section className="py-20 lg:py-28 bg-[#F9F9FB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1F2933] mb-4">
            Built for the way you work
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {useCases.map((useCase, idx) => (
            <motion.div
              key={useCase.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="relative bg-white rounded-2xl p-8 hover:shadow-xl transition-all duration-300 border-l-4 border-[#FF8A3D] overflow-hidden"
            >
              <div
                className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${useCase.gradient} opacity-5 rounded-full -mr-16 -mt-16`}
              />

              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-[#FF8A3D]/10 to-[#F45B5B]/10 rounded-xl flex items-center justify-center mb-6">
                  <useCase.icon className="w-6 h-6 text-[#FF8A3D]" />
                </div>

                <h3 className="text-xl font-bold text-[#1F2933] mb-4">
                  {useCase.title}
                </h3>

                <p className="text-gray-600 leading-relaxed">
                  {useCase.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

