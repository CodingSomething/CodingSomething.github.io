const logos = ['Acme', 'Globex', 'Initech', 'Umbrella', 'Hooli', 'Stark'];

export default function TrustBar() {
  return (
    <section className="px-6 py-12 bg-white border-b border-slate-100">
      <div className="max-w-5xl mx-auto text-center space-y-6">
        <p className="uppercase text-xs tracking-[0.2em] text-slate-500">
          Trusted by modern GTM teams
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6 text-slate-400 text-sm font-semibold">
          {logos.map((logo) => (
            <div
              key={logo}
              className="border border-slate-200 rounded-lg py-4 px-3"
            >
              {logo}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

