import React from 'react';

function cn(...classes) {
  return classes.filter(Boolean).join(' ');
}

const Badge = React.forwardRef(({ className = '', children, ...props }, ref) => (
  <span
    ref={ref}
    className={cn(
      'inline-flex items-center rounded-full border border-transparent px-3 py-1 text-xs font-semibold uppercase tracking-wide',
      className,
    )}
    {...props}
  >
    {children}
  </span>
));

Badge.displayName = 'Badge';

export { Badge };

