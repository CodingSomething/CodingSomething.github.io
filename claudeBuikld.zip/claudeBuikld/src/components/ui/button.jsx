import React from 'react';

const baseClass =
  'inline-flex items-center justify-center rounded-xl font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-white disabled:opacity-50 disabled:pointer-events-none';

const variantClass = {
  default: 'bg-[#1F2933] text-white hover:bg-[#111827]',
  outline: 'border border-gray-300 text-[#1F2933] bg-transparent hover:bg-gray-50',
};

const sizeClass = {
  md: 'h-11 px-6 text-sm',
  lg: 'h-14 px-7 text-base',
};

function cn(...classes) {
  return classes.filter(Boolean).join(' ');
}

const Button = React.forwardRef(
  ({ className = '', variant = 'default', size = 'md', type = 'button', ...props }, ref) => (
    <button
      ref={ref}
      type={type}
      className={cn(baseClass, variantClass[variant] ?? variantClass.default, sizeClass[size] ?? sizeClass.md, className)}
      {...props}
    />
  ),
);

Button.displayName = 'Button';

export { Button };

