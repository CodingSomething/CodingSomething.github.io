import React from 'react';
import Hero from './components/landing/Hero.jsx';
import TrustBar from './components/landing/TrustBar.jsx';
import HowItWorks from './components/landing/HowItWorks.jsx';
import Features from './components/landing/Features.jsx';
import UseCases from './components/landing/UseCases.jsx';
import WhyChooseUs from './components/landing/WhyChooseUs.jsx';
import DemoPreview from './components/landing/DemoPreview.jsx';
import Pricing from './components/landing/Pricing.jsx';
import FAQ from './components/landing/FAQ.jsx';
import FinalCTA from './components/landing/FinalCTA.jsx';
import Footer from './components/landing/Footer.jsx';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <TrustBar />
      <HowItWorks />
      <Features />
      <UseCases />
      <WhyChooseUs />
      <DemoPreview />
      <Pricing />
      <FAQ />
      <FinalCTA />
      <Footer />
    </div>
  );
}

